package com.parttimecoder.lasttry.controller;


import com.parttimecoder.lasttry.model.User;
import com.parttimecoder.lasttry.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    @Autowired
    private UserService userService;

   /* @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        // Extract the username and password from the request body
        return userService.login(user.getUsername(), user.getPassword());
    }
*/

    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody User user) {
        System.out.println("Request received: " + user);
        return userService.login(user.getUsername(), user.getPassword());
    }
        @PostMapping("/signup")
    public ResponseEntity<?> signup(@RequestBody User user) {
        return userService.signup(user);
    }
}
