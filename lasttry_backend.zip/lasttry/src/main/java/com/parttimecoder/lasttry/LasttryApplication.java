package com.parttimecoder.lasttry;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LasttryApplication {

	public static void main(String[] args) {
		SpringApplication.run(LasttryApplication.class, args);
	}

}
