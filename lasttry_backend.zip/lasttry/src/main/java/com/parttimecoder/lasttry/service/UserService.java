package com.parttimecoder.lasttry.service;

import com.parttimecoder.lasttry.model.User;
import com.parttimecoder.lasttry.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Map;
import java.util.HashMap;
import java.util.List;
import java.util.Optional;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    private BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();

   /*public ResponseEntity<?> login(String username, String password) {
       User user = userRepository.findByUsername(username);

       if (user == null) {
           System.out.println("User not found: " + username);
           return ResponseEntity.status(401).body("Invalid credentials");
       }

       // Check if the provided password matches the stored hashed password
       if (passwordEncoder.matches(password, user.getPassword())) {
           return ResponseEntity.ok("Login successful!");
       } else {
           System.out.println("Password does not match for user: " + username);
           return ResponseEntity.status(401).body("Invalid credentials");
       }
   }*/

   /* public ResponseEntity<?> login(String username, String password) {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            System.out.println("User not found: " + username);
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        // Check if the provided password matches the stored hashed password
        if (passwordEncoder.matches(password, user.getPassword())) {
            // Include the user's role in the response
            String responseMessage = "Login successful! Role: " + user.getRole();
            return ResponseEntity.ok(responseMessage);
        } else {
            System.out.println("Password does not match for user: " + username);
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }
*/
    // working code
    public ResponseEntity<?> login(String username, String password) {
        User user = userRepository.findByUsername(username);

        if (user == null) {
            System.out.println("User not found: " + username);
            return ResponseEntity.status(401).body("Invalid credentials");
        }

        if (passwordEncoder.matches(password, user.getPassword())) {
            // Create a structured response with the ID and role
            Map<String, Object> response = new HashMap<>();
            response.put("message", "Login successful");
            response.put("id", user.getId());
            response.put("role", user.getRole());

            return ResponseEntity.ok(response);
        } else {
            System.out.println("Password does not match for user: " + username);
            return ResponseEntity.status(401).body("Invalid credentials");
        }
    }


   /* public ResponseEntity<?> signup(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully!");
    }*/

    public ResponseEntity<?> signup(User user) {
        if (user.getPassword() == null || user.getPassword().isEmpty()) {
            return ResponseEntity.badRequest().body("Password is required.");
        }
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return ResponseEntity.ok("User registered successfully!");
    }

    /*public ResponseEntity<?> updateUser(Long userId, User updatedUser) {
        // Check if user exists in the database
        return userRepository.findById(userId).map(user -> {
            // Update user details
            user.setUsername(updatedUser.getUsername());
            // Ensure password is encoded before saving
            user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
            user.setExperience(updatedUser.getExperience());
            user.setSkills(updatedUser.getSkills());
            user.setRole(updatedUser.getRole());

            // Save updated user
            userRepository.save(user);

            // Return success response
            return ResponseEntity.ok("User updated successfully!");
        }).orElse(ResponseEntity.status(404).body("User not found"));
    }*/

    public ResponseEntity<?> updateUser(Long userId, User updatedUser) {
        System.out.println("Updating user with ID: " + userId);

        // Check if user exists in the database
        return userRepository.findById(userId).map(user -> {
            // Update user details
            System.out.println("User found, updating details...");
            user.setUsername(updatedUser.getUsername());
            user.setPassword(passwordEncoder.encode(updatedUser.getPassword()));
            user.setExperience(updatedUser.getExperience());
            user.setSkills(updatedUser.getSkills());
            user.setRole(updatedUser.getRole());

            // Save updated user
            userRepository.save(user);
            return ResponseEntity.ok("User updated successfully!");
        }).orElse(ResponseEntity.status(404).body("User not found"));
    }

    public ResponseEntity<?> getCurrentUser(String username) {
        Optional<User> userOptional = Optional.ofNullable(userRepository.findByUsername(username));

        if (userOptional.isPresent()) {
            return ResponseEntity.ok(userOptional.get()); // Return user if found
        } else {
            return ResponseEntity.status(404).body("User not found"); // Return 404 if not found
        }
    }
    public ResponseEntity<?> createUser(User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        userRepository.save(user);
        return ResponseEntity.ok("User created successfully!");
    }

    /*public ResponseEntity<?> getAllUsers() {
        List<User> users = userRepository.findAll();
        return ResponseEntity.ok(users);
    }*/

    public ResponseEntity<?> getAllUsers() {
        try {
            List<User> users = userRepository.findAll();
            if (users.isEmpty()) {
                // No users found in the database
                return ResponseEntity.status(HttpStatus.NO_CONTENT).body("No users found");
            }
            return ResponseEntity.ok(users);  // Return users if they exist
        } catch (Exception e) {
            // Log the exception for debugging purposes
            System.out.println("Error retrieving users: " + e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error retrieving users");
        }
    }
}
