package com.parttimecoder.lasttry.controller;


import com.parttimecoder.lasttry.model.User;
import com.parttimecoder.lasttry.service.UserService;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/users")
public class UserController {

    @Autowired
    private UserService userService;

   /* @GetMapping("/current")
    public ResponseEntity<?> getCurrentUser(HttpServletRequest request) {
        // Check if the user is authenticated
        if (request.getUserPrincipal() == null) {
            return ResponseEntity.status(401).body("User is not authenticated.");
        }

        String username = request.getUserPrincipal().getName(); // Extracts the username from the security context

        // In case of any further issues with username retrieval, handle gracefully
        if (username == null || username.isEmpty()) {
            return ResponseEntity.status(400).body("Username is not available.");
        }

        // Retrieve the user details from the service
        return userService.getCurrentUser(username);
    }


    @PutMapping("/{userId}")
    public ResponseEntity<?> updateUser(@PathVariable Long userId, @RequestBody User user) {
        // Validate input userId and user object
        if (userId == null || user == null) {
            return ResponseEntity.badRequest().body("Invalid userId or user data!");
        }
        return userService.updateUser(userId, user);
    }*/

    // Get current user details
    @GetMapping("/current")
    public ResponseEntity<?> getCurrentUser(HttpServletRequest request) {
        // Check if the user is authenticated
        if (request.getUserPrincipal() == null) {
            return ResponseEntity.status(401).body("User is not authenticated.");
        }

        String username = request.getUserPrincipal().getName(); // Extracts the username from the security context

        if (username == null || username.isEmpty()) {
            return ResponseEntity.status(400).body("Username is not available.");
        }

        // Retrieve the user details from the service
        return userService.getCurrentUser(username);
    }

    // Update user details
    @PutMapping("/{userId}")
    public ResponseEntity<?> updateUser(@PathVariable Long userId, @RequestBody User updatedUser) {
        if (userId == null || updatedUser == null) {
            return ResponseEntity.badRequest().body("Invalid userId or user data!");
        }
        return userService.updateUser(userId, updatedUser);
    }


    @PostMapping
    public ResponseEntity<?> createUser(@RequestBody User user) {
        return userService.createUser(user);
    }
}

@RestController
@RequestMapping("/api/resources")
class ResourceController {

    @Autowired
    private UserService userService;

    @GetMapping
    public ResponseEntity<?> getAllUsers() {
        return userService.getAllUsers();
    }
}
